<?php
// ini_set('display_errors', 1);
// error_reporting(E_ALL);

$hostname = 'localhost';
$dbname = 'exam';
$username = 'root';
$password = 'root'; // Убедитесь, что это ваш реальный пароль

try {
    $connect = new PDO("mysql:host=$hostname;dbname=$dbname;charset=utf8", $username, $password);
    echo "";
} catch (PDOException $e) {
    echo "" . $e->getMessage();
}

// Точка проверки вывода
?>
