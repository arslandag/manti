<?php
// session_start(); 
include('incl/connect.php');

if(isset($_SESSION['users'])){
    $id =$_SESSION['users'];
    $sql="SELECT * FROM `users` WHERE `id` = '$id'";
    $users = $connect->query($sql)->fetch();  
}


if(isset($_GET['exit'])){
    unset($_SESSION['users']);
    echo '<script> document.location.href="?page=lk"</script>';
}
?>