<?php include('incl/connect.php');
include('incl/head.php');
ini_set('display_errors', 0);

if (isset($_GET['exit'])) {
    session_unset();
    session_destroy();
    echo '<script> document.location.href="?page=sign"</script>';
    exit();
}

$page = isset($_GET['page']) ? $_GET['page'] : 'main';

?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="shortcut icon" href="assets/media/logo_footluck.svg" type="image/x-icon">
    <title>skincare
    </title>
</head>

<body>
    <?php

    include('components/header.php');

    if (isset($_GET['page'])) {
        // if ($_GET['page'] == 'catalog') {
        //     include('pages/catalog.php');
        // };
        if ($_GET['page'] == 'profile') {
            include('pages/profile.php');
        };
        if (isset($_GET['page'])) {
            // echo "Current page: " . $_GET['page'];
            // Ваши условия здесь
        } else {
            echo "Default main page";
            include('pages/main.php');
        }

        if ($_GET['page'] == 'registration') {
            include('pages/registration.php');
        };
        if ($_GET['page'] == 'authorization') {
            include('pages/authorization.php');
        };

        if ($_GET['page'] == 'ppage') {
            include('pages/ppage.php');
        };
        if ($_GET['page'] == 'admin') {
            include('pages/admin.php');
        };
        if ($_GET['page'] == 'admin_program') {
            include('pages/admin_program.php');
        };
        if ($_GET['page'] == 'admin_team') {
            include('pages/admin_team.php');
        };
        if ($_GET['page'] == 'admin_zayavka') {
            include('pages/admin_zayavka.php');
        };
        if ($_GET['page'] == 'zakaz') {
            include('pages/zakaz.php');
        };
        if ($_GET['page'] == 'change') {
            include('pages/change.php');
        };
        if ($_GET['page'] == 'delete') {
            include('pages/delete.php');
        };
        if ($_GET['page'] == 'deletepl') {
            include('pages/deletepl.php');
        };
        if ($_GET['page'] == 'add') {
            include('pages/add.php');
        };
        if ($_GET['page'] == 'addd') {
            include('pages/addd.php');
        };
        if ($_GET['page'] == 'add_player') {
            include('pages/add_player.php');
        };
        if ($_GET['page'] == 'team') {
            include('pages/team.php');
        };
        if ($_GET['page'] == 'about') {
            include('pages/about.php');
        };
        if ($_GET['page'] == 'main') {
            include('pages/main.php');
        };
        if ($_GET['page'] == 'del_remove') {
            include('pages/del_remove.php');
        };
        if ($_GET['page'] == 'change_tov') {
            include('pages/change_tov.php');
        };
        if ($_GET['page'] == 'changepl') {
            include('pages/changepl.php');
        };
        if ($_GET['page'] == 'catalog_upd') {
            include('pages/catalog_upd.php');
        };
        
    } else {
        include('pages/main.php');
    }
    if (!str_contains($_GET['page'], 'admin')) {
        include('components/footer.php');
    }
    





    ?>

    <script src="script/script.js"></script>
</body>

</html>