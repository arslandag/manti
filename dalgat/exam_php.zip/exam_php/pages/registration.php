<?php
if (isset($_POST['reg'])) {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    // $phone = $_POST['phone'];
    $password = $_POST['password'];
    $password_r = $_POST['password_r'];

    $flag = 'true';

    $errors = [
        '<p class="error">Заполните поле ввода</p>',
        '<p class="error">Не верный формат почты</p>',
        '<p class="error">Вы уже зарегистированы </p>',
        '<p class="error">Пароль должен включать не менее 6 символов</p>',
        '<p class="error">Пароли не совпадают</p>'
    ];
}


?>

<main>
    <div class="out_wrapper">
        <form action="" class="form" name="reg" method="POST">
            <h1>Регистрация</h1>
            <p class="error">Заполните все поля</p>
            <input type="text" name="name" placeholder="Имя*">
            <?php
            if (isset($_POST['reg'])) {
                if (empty($name)) {
                    $flag = 'false';
                    echo $errors[0];
                }
            } ?>

            <input type="text" name="surname" placeholder="Фамилия*">
            <?php
            if (isset($_POST['reg'])) {
                if (empty($surname)) {
                    $flag = 'false';
                    echo $errors[0];
                }
            } ?>
            <input type="text" name="lastname" placeholder="Отчество">
            <?php
            if (isset($_POST['reg'])) {
                if (empty($lastname)) {
                    $flag = 'false';
                    echo $errors[0];
                }
            } ?>

            <input type="email" name="email" placeholder="Почта*">
            <?php
            if (isset($_POST['reg'])) {
                if (empty($email)) {
                    $flag = 'false';
                    echo $errors[0];
                } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $flag = 'false';
                    echo $errors[1];
                } else {
                    $sql = "SELECT * FROM `users` WHERE `email` = '$email'";
                    $res = $connect->query($sql)->fetchColumn();
                    if ($res != 0) {
                        $flag = 'false';
                        echo $errors[2];
                    }
                }
            } ?>
            <input type="password" name="password" placeholder="Пароль*">
            <?php
            if (isset($_POST['reg'])) {
                if (empty($password)) {
                    $flag = 'false';
                    echo $errors[0];
                }
            } ?>
            <input type="password" name="password_r" placeholder="Повторите пароль*">
            <?php
            if (isset($_POST['reg'])) {
                if (empty($password_r)) {
                    $flag = 'false';
                    echo $errors[0];
                } elseif (strlen($password) < 6) {
                    $flag = 'false';
                    echo $errors[3];
                } elseif ($password != $password_r) {
                    $flag = 'false';
                    echo $errors[4];
                }
            } ?>
            <div class="rules_wrapper">
                <input type="checkbox" id="rules">
                <label for="rules">Соглашаюсь с <a class="rules_link" href="">правилами регистрации</a></label>
            </div>
            <input class="form_btn" type="submit" name="reg" value="Зарегистрироваться">
        </form>
        <?php
        if (isset($_POST['reg'])) {
            if ($flag != 'false') {
                $password = password_hash($password, PASSWORD_DEFAULT);
                $sql = "INSERT INTO `users` (`name`, `surname`, `lastname`, `email`, `role`, `password`) VALUES (?, ?, ?, ?, '1', ?)";
                $stmt = $connect->prepare($sql);
                $stmt->execute([$name, $surname, $lastname, $email, $password]);
                header('Location: ?page=profile');
                exit();
            }
        } ?>
    </div>
</main>

</body>

</html>