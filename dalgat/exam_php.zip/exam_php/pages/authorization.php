<?php
// session_start(); // Начинаем сессию

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $flag = true; // Лучше использовать булев тип
    $errors = [
        '<p class="error">Заполните поле ввода</p>',
        '<p class="error">Вы не зарегистрированы</p>',
        '<p class="error">Неверный логин или пароль</p>'
    ];

    if (empty($email)) {
        echo $errors[0];
        $flag = false;
    } else {
        $stmt = $connect->prepare("SELECT * FROM `users` WHERE `email` = :email");
        $stmt->execute(['email' => $email]);
        $res = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$res) {
            echo $errors[1];
            $flag = false;
        } elseif (empty($password) || !password_verify($password, $res['password'])) {
            echo $errors[2];
            $flag = false;
        }

        if ($flag) {
            $_SESSION['USER'] = $res['id'];
            echo '<script>document.location.href="?page=profile";</script>';
        }
    }
}
?>

<main>
    <div class="out_wrapper">
        <form action="" class="form" method="POST" name="login">
            <h1>Авторизация</h1>
            <input type="email" placeholder="Почта@" name="email" class="underline-input" value="<?= htmlspecialchars($email ?? '') ?>">
            <input type="password" name="password" placeholder="Пароль">
            <input class="form_btn" type="submit" name="login" value="Авторизоваться">
        </form>
    </div>
</main>

</body>

</html>