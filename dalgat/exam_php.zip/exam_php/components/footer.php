<footer>
        <div class="header_wrapper footer_wrapper">
            <a href="" class="logo footer_logo">
                <svg width="113" height="113" viewBox="0 0 113 113" fill="" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd"
                        d="M56.6674 0L56.6679 1.48894e-06C56.7583 31.0711 81.9289 56.2418 113 56.3321V56.3325C81.873 56.4231 56.6677 81.6843 56.6677 112.833C56.6677 112.888 56.6678 112.944 56.6679 113C56.6677 113 56.6676 113 56.6674 113L56.6677 112.833C56.6677 81.6553 31.4153 56.376 0.248305 56.3323C31.3594 56.2888 56.577 31.1001 56.6674 0ZM0 56.3325L5.43761e-07 56.3322L0.109126 56.3323L0 56.3325Z"
                        fill="" />
                </svg>
                <p>Skin Care</p>
            </a>
            <div class="footer_text_wrapper_out">
                <div class="footer_text_wrapper">
                    <p class="footer_title">КОНТАКТЫ</p>
                    <a href="">+7 (999) 999-99-99</a>
                    <a href="">Vk: Skin Care</a>
                    <a href="">Tg: Skin Care</a>
                </div>
                <div class="footer_text_wrapper">
                    <p class="footer_title">МАГАЗИН</p>
                    <a href="">Каталог</a>
                    <a href="">О магазине</a>
                    <a href="">Акции</a>
                </div>
                <div class="footer_text_wrapper">
                    <p class="footer_title">ИНФОРМАЦИЯ</p>
                    <a href="">Доставка и оплата</a>
                    <a href="">Пользовательское соглашение</a>
                    <a href="">Профиль</a>
                </div>
            </div>
        </div>
    </footer>